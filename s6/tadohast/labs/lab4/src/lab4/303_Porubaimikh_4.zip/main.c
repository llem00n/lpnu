int main() {
	/* Oleksandr Porubaimikh */
	return 0;
}